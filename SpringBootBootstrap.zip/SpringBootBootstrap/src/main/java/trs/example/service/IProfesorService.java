package trs.example.service;

import org.springframework.stereotype.Component;

@Component
public interface IProfesorService {

}
