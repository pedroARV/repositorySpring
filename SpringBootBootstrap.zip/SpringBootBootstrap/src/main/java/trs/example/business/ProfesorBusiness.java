package trs.example.business;

import org.springframework.stereotype.Service;

import trs.example.service.IProfesorService;

@Service
public class ProfesorBusiness implements IProfesorService {

}
